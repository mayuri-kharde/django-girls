from django.db import models

class Story(models.Model):
    grapher_name = models.CharField(max_length=200)
    story_name = models.CharField(max_length=200)
    description = models.TextField()
    duration = models.IntegerField()
    file_type = models.FileField()
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    timestamp = models.DateTimeField()

    def __str__(self):
        return self.story_name



class ResizeQueue(models.Model):
    story = models.ForeignKey(Story)