from django.apps import AppConfig


class GraphyConfig(AppConfig):
    name = 'graphy'
