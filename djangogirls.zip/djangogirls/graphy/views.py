from rest_framework import viewsets

from .serializers import StorySerializer
from .models import Story


class StoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Story.objects.all().order_by('-timestamp')
    serializer_class = StorySerializer


class CreateStoryViewSet(viewsets.ModelViewSet):
    