from rest_framework import serializers

from .models import Story

class StorySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Story
        fields = ('grapher_name', 'story_name', 'description', 'duration', 'file_type', 'latitude', 'longitude', 'timestamp')